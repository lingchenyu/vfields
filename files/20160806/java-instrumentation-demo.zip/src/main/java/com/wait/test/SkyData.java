package com.wait.test;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by wait on 2016/8/6.
 */
public class SkyData {
    private int number;
    private List<Sky> skies;

    public void add() {
        number++;
        if (skies == null) {
            skies = new ArrayList<>();
            skies.add(Sky.valueOf(number));
        }
    }

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public List<Sky> getSkies() {
        return skies;
    }

    public void setSkies(List<Sky> skies) {
        this.skies = skies;
    }


    @Override
    public String toString() {
        return "SkyData{" +
                "number=" + number +
                ", skies=" + skies.hashCode() + "(" + skies + ")" +
                '}';
    }
}
