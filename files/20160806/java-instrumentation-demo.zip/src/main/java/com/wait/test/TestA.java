package com.wait.test;

import java.io.IOException;
import java.lang.instrument.ClassDefinition;
import java.lang.instrument.Instrumentation;
import java.lang.instrument.UnmodifiableClassException;
import java.nio.file.Files;
import java.nio.file.Paths;

/**
 * Created by wait on 2016/8/5.
 */
public class TestA {

    public static void main(String[] args) throws IOException, UnmodifiableClassException, ClassNotFoundException {
        SkyData skyData = new SkyData();
        skyData.add();
        System.err.println(skyData);
        if (JavaAgent.getIns() != null) {
            byte[] data = Files.readAllBytes(Paths.get("E:/iwork/w/target/classes/com/wait/test/", "SkyData.class"));
            Instrumentation ins = JavaAgent.getIns();
            ins.redefineClasses(new ClassDefinition(SkyData.class, data));
            System.err.println(skyData);
        }
    }
}
