package com.wait.test;

import java.lang.instrument.Instrumentation;

/**
 * Created by wait on 2016/8/5.
 */
public class JavaAgent {
    private static Instrumentation ins;

    public static void premain(String args, Instrumentation inst) {
        ins = inst;
    }

    public static void agentmain(String args, Instrumentation inst) throws Exception {
        ins = inst;
    }

    public static Instrumentation getIns() {
        return ins;
    }
}
