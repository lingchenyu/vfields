package com.wait.test;

/**
 * Created by wait on 2016/8/6.
 */
public class Sky {
    private int id;

    public static Sky valueOf(int id) {
        Sky sky = new Sky();
        sky.id = id;
        return sky;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}
